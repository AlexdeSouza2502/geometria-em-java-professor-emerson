
package Matriz;
import java.util.*;


public class Main {
    public static void main(String[] args) { 
    Matriz matriz = new Matriz();// instanciando a classe
    Scanner enter = new Scanner(System.in);
    
    System.out.print("Qual o tamanho da matriz 1? ");
    int coluna = enter.nextInt(); // pedindo para o usuario entar com o tamanho das colunas da matriz
    int linha = enter.nextInt();// idem
    
    }
    
}
